# npx cdk list -c dlz-script=bootstrap
# python3 app.py -- --dlz-script=bootstrap
python3 scripts.py --function=bootstrap