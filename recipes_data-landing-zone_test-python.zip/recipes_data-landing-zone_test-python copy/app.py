#!/usr/bin/env python3
import os
import aws_cdk as cdk
import recipes_dlz as dlz
from config import config

app = cdk.App()

dlz.DataLandingZone(app,
                    local_profile=config.local_profile,
                    accounts=config.accounts,
                    regions=config.regions
                    )

# dlz.DataLandingZone(app,
#                     local_profile="ct-sandbox-exported",
#                     accounts=dlz.DLzAccounts(
#                         management=dlz.DLzAccount(
#                             account_id="882070149987",
#                         ),
#                         log=dlz.DLzAccount(
#                             account_id="730335597466",
#                         ),
#                         audit=dlz.DLzAccount(
#                             account_id="851725452335",
#                         ),
#                     ),
#                     regions=dlz.DlzRegions(
#                         global_=dlz.Region.EU_WEST_1,
#                         regional=[dlz.Region.US_EAST_1],
#                         )
#                     )

app.synth()
