import argparse
import recipes_dlz as dlz
from config import config
from time import sleep

def bootstrap():
    print("Start")
    dlz.DlzScriptBootstrap().management(
        local_profile=config.local_profile,
        accounts=config.accounts,
        regions=config.regions
    )
    print("OKAYY")
    print("OKAYY")
    print("OKAYY")
    print("OKAYY")
    sleep(1)
    dlz.DlzScriptBootstrap().management(
        local_profile=config.local_profile,
        accounts=config.accounts,
        regions=config.regions
    )
    print("End")
    # dlz.DlzScriptBootstrap().management_spawn(
    #     local_profile=config.local_profile,
    #     accounts=config.accounts,
    #     regions=config.regions
    # )
    # dlz.DlzScriptBootstrap().management(
    #     local_profile=config.local_profile,
    #     accounts=config.accounts,
    #     regions=config.regions
    # )
    # dlz.DlzScriptBootstrap().management_non_static(
    #     local_profile=config.local_profile,
    #     accounts=config.accounts,
    #     regions=config.regions
    # )


parser = argparse.ArgumentParser()
parser.add_argument('--function', type=str, help='Name of the function to call')
args = parser.parse_args()

function_name = args.function
function_map = {
    'bootstrap': bootstrap,
}
if function_name not in function_map:
    print(f"Error: Function '{function_name}' not found.")
    exit()

function_map[function_name]()