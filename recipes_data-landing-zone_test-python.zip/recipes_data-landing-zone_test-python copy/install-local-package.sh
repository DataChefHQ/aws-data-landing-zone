#tar -xf /Users/rehanvandermerwe/DataChef/Projects/recipes_data-landing-zone_data-landing-zone/dist/python/recipes_data-landing-zone_data-landing-zone-0.0.0.tar.gz
#python3 -m pip install -e recipes_data-landing-zone_data-landing-zone-0.0.0

npm run compile --prefix /Users/rehanvandermerwe/DataChef/Projects/recipes_data-landing-zone_data-landing-zone
npm run package:python --prefix /Users/rehanvandermerwe/DataChef/Projects/recipes_data-landing-zone_data-landing-zone
tar -xf /Users/rehanvandermerwe/DataChef/Projects/recipes_data-landing-zone_data-landing-zone/dist/python/recipes_dlz-0.0.0.tar.gz
python3 -m pip install -e recipes_dlz-0.0.0