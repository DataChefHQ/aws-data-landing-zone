import recipes_dlz as dlz

# No typing on this, so use class instead of dict
# config = {
#     "local_profile": "ct-sandbox-exported",
#     "accounts": dlz.DLzAccounts(
#         management=dlz.DLzAccount(account_id="882070149987"),
#         log=dlz.DLzAccount(account_id="730335597466"),
#         audit=dlz.DLzAccount(account_id="851725452335"),
#     ),
#     "regions": dlz.DlzRegions(
#         global_=dlz.Region.EU_WEST_1,
#         regional=[dlz.Region.US_EAST_1],
#     )
# }

class Configuration:
    def __init__(self):
        self.local_profile = "ct-sandbox-exported"
        self.accounts = dlz.DLzAccounts(
            management=dlz.DLzAccount(account_id="882070149987"),
            log=dlz.DLzAccount(account_id="730335597466"),
            audit=dlz.DLzAccount(account_id="851725452335"),
        )
        self.regions = dlz.DlzRegions(
            global_=dlz.Region.EU_WEST_1,
            regional=[dlz.Region.US_EAST_1],
        )


config = Configuration()
